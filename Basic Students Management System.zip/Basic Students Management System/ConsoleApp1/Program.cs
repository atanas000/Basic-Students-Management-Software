﻿using System;
using System.Collections.Generic;

namespace SchoolManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>();
            int choice;
            do
            {
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. Show Students");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter student name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter student age: ");
                        int age = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter student grade: ");
                        string grade = Console.ReadLine();

                        Student student = new Student
                        {
                            Name = name,
                            Age = age,
                            Grade = grade
                        };
                        students.Add(student);
                        break;

                    case 2:
                        Console.WriteLine("Name\tAge\tGrade");
                        foreach (var studen in students)
                        {
                            Console.WriteLine($"{studen.Name}\t{studen.Age}\t{studen.Grade}");
                        }
                        break;
                }
            } while (choice != 3);
        }
    }

    class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Grade { get; set; }
    }
}
